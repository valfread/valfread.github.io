This is an example site for testing purposes.

Structure is available for reference.