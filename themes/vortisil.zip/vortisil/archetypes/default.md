---
title: "{{ replace .File.ContentBaseName "-" " " | title }}"
date: {{ .Date }}
draft: true # 如想要发布，请务必修改为 false
author: Qingshanyima
comments: true
tags: []
license: "CC-BY-NC-ND 4.0 "
license_url: "https://creativecommons.org/licenses/by-nc-nd/4.0/"
---